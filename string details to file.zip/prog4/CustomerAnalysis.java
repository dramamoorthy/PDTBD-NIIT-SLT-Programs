//Write a program to get student details and store it into a file and print the name of the students who are eligible to vote.

import java.util.*;
import java.io.*;


class CustomerAnalysis
{
public static void main(String[] args)
{
Scanner scr = new Scanner(System.in);
System.out.println("Enter the total number of Customer");
int n = scr.nextInt();

CustomerDetails std = new CustomerDetails();
std.getDetails(n);
try {
PrintStream output = new PrintStream(new File("CustomerDetails.txt"));
for(int i=0;i<n;i++)
{
for(int j=0;j<10;j++)
{
output.print(std.name[i][j]+"\t\t");
}
output.println();
}
output.close();
    }
catch(FileNotFoundException e)
{
System.out.println("File not found");
}

//
String str3[][]=new String[51][51];
try{
File inputFile = new File("CustomerDetails.txt");
Scanner data = new Scanner(inputFile);

for(int i=0;i<n;i++)
{
for(int j=0;j<10;j++)
{
str3[i][j]=data.next();
}
}
}
catch(FileNotFoundException e)
{
System.out.println("error");
}
/*
for(int i=0;i<n;i++)
{
for(int j=0;j<10;j++)
{
System.out.print(str3[i][j]);
System.out.print("\t");
}


System.out.println();
}
*/

//logic to print students age above 21.


for(int l=0;l<n;l++)
{
int k =6;
int p = Integer.parseInt(str3[l][3]);
if(p>10)
{
System.out.println("The  customer "+ str3[l][1]+" is older than 10 years");
}
}
int counta=0;
for(int l=0;l<n;l++)
{
int p = Integer.parseInt(str3[l][8]);
if(p==0)
{
counta ++;
}
}
System.out.println("The number of customers who does not have a phone are "+counta);


int countm=0;
int countf=0;
for(int l=0;l<n;l++)
{
if((str3[l][2]).equals("m"))
{
countm ++;
}
else
countf ++;
}
System.out.println("The number of male customers is  "+countm +" The number of female customers is "+countf);



System.out.println("Total number of Customers country wise is");

Map<String,Integer> mapofrepeat = new HashMap<String,Integer>();

for(int i=0;i<n;i++)
{
String tempUCword = (str3[i][6]).toUpperCase();
if(mapofrepeat.containsKey(tempUCword))
{
mapofrepeat.put(tempUCword,mapofrepeat.get(tempUCword)+1);
}
else
{
mapofrepeat.put(tempUCword,1);
}
}

for(Map.Entry<String,Integer>entry:mapofrepeat.entrySet())
{
System.out.println(entry.getKey()+"\t\t"+entry.getValue());
}
Map.Entry<String,Integer> entry1 = mapofrepeat.entrySet().iterator().next();
String key = entry1.getKey();
Integer value = entry1.getValue();
//System.out.print(key);
//System.out.print(value);
//System.out.println(" ");




//

}
}

class CustomerDetails
{
public String name[][] = new String[51][51];
void getDetails(int n)
{
Scanner scr1 = new Scanner(System.in);

int limit = n;
System.out.println("Enter "+ limit + " Customer details" );
for(int i =0; i<limit;i++)
{
System.out.println("Enter details of Cusotmer no. "+ (i+1)+ " Id"+" Name"+ " Gender"+" Age"+" Address"+" City"+" Country"+" Pin"+" phone"+" DOB");
for(int j=0;j<10;j++)
{
//
if(j==0)
{
System.out.println(" ");
System.out.println("Enter the customer ID ");

}
//
else if(j==1)
{
System.out.println(" ");
System.out.println("Enter the customer name");
}

else if(j==2)
{
System.out.println(" ");
System.out.println("Enter the customer gender as M or F");
}


else if(j==3)
{
System.out.println(" ");
System.out.println("Enter the age");
}

else if(j==4)
{
System.out.println(" ");
System.out.println("Enter the address");
}

else if(j==5)
{
System.out.println(" ");
System.out.println("Enter the city");
}

else if(j==6)
{
System.out.println(" ");
System.out.println("Enter the product country");
}

else if(j==7)
{
System.out.println(" ");
System.out.println("Enter the pin");
}

else if(j==8)
{
System.out.println(" ");
System.out.println("Enter the phone,if doesn't have a phone enter 0");
}

else if(j==9)
{
System.out.println(" ");
System.out.println("Enter the DOB");
}







name [i][j] = scr1.nextLine(); 


}
}
display(limit);
}

void display(int limit)
{
System.out.println("ID"+"\t"+"Name"+"\t"+ "Gender"+"Age"+"\t"+"Address"+"\t"+"City"+"\t"+"Country"+"\t"+"Pin"+"\t"+"Phone"+"\t"+"DOB");
for(int i=0;i<limit;i++)
{
for(int j =0;j<8;j++)
{
System.out.print(name[i][j]+"\t");
}
System.out.println();
}
}
}
