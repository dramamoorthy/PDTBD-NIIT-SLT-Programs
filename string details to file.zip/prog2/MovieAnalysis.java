//Write a program to get student details and store it into a file and print the name of the students who are eligible to vote.

import java.util.*;
import java.io.*;


class MovieAnalysis
{
public static void main(String[] args)
{
Scanner scr = new Scanner(System.in);
System.out.println("Enter the total number of movies");
int n = scr.nextInt();

MovieDetails std = new MovieDetails();
std.getDetails(n);
try {
PrintStream output = new PrintStream(new File("MovieDetails.txt"));
for(int i=0;i<n;i++)
{
for(int j=0;j<7;j++)
{
output.print(std.name[i][j]+"\t\t");
}
output.println();
}
output.close();
    }
catch(FileNotFoundException e)
{
System.out.println("File not found");
}

//
String str3[][]=new String[51][51];
try{
File inputFile = new File("MovieDetails.txt");
Scanner data = new Scanner(inputFile);

for(int i=0;i<n;i++)
{
for(int j=0;j<7;j++)
{
str3[i][j]=data.next();
}
}
}
catch(FileNotFoundException e)
{
System.out.println("error");
}
/*
for(int i=0;i<n;i++)
{
for(int j=0;j<7;j++)
{
System.out.print(str3[i][j]);
System.out.print("\t");
}


System.out.println();
}
*/

//logic to print students age above 21.


for(int l=0;l<n;l++)
{
int k =6;
int p = Integer.parseInt(str3[l][6]);
if(p==2015)
{
System.out.println("The  movie "+ str3[l][1]+" released in the year 2015");
}
}


for(int l=0;l<n;l++)
{
if((str3[l][5]).equals("u"))
{
System.out.println("The  movie "+ str3[l][1]+" is of type U ");
}
}

for(int l=0;l<n;l++)
{
int k =4;
int p = Integer.parseInt(str3[l][4]);
if(p>4)
{
System.out.println("The  movie "+ str3[l][1]+" has rating greater than 4");
}
}

for(int l=0;l<n;l++)
{
String a="khan";
//int p = Integer.parseInt(str3[l][3]);
if((str3[l][3]).contains("khan"))
{
System.out.println("The  movie "+ str3[l][1]+" has khan as an actor");
}
}







//

}
}

class MovieDetails
{
public String name[][] = new String[51][51];
void getDetails(int n)
{
Scanner scr1 = new Scanner(System.in);

int limit = n;
System.out.println("Enter "+ limit + " Movie details" );
for(int i =0; i<limit;i++)
{
System.out.println("Enter Movie No. "+ (i+1)+ " Id"+" Name"+ " Director"+" Actor"+" Rating"+" Type"+" Release_Date");
for(int j=0;j<7;j++)
{
//
if(j==0)
{
System.out.println(" ");
System.out.println("Enter the movie ID ");

}
//
else if(j==1)
{
System.out.println(" ");
System.out.println("Enter the movie Name");
}

else if(j==2)
{
System.out.println(" ");
System.out.println("Enter the name of director");
}


else if(j==3)
{
System.out.println(" ");
System.out.println("Enter the name of actor");
}

else if(j==4)
{
System.out.println(" ");
System.out.println("Enter the rating of movie");
}

else if(j==5)
{
System.out.println(" ");
System.out.println("Enter the movie type");
}

else if(j==6)
{
System.out.println(" ");
System.out.println("Enter the release year");
}





name [i][j] = scr1.nextLine(); 


}
}
display(limit);
}

void display(int limit)
{
System.out.println("MovieID"+"\t"+"Name"+"\t"+ "Director "+"Actor"+"\t"+"Rating"+"\t"+"Type"+"\t"+"year");
for(int i=0;i<limit;i++)
{
for(int j =0;j<7;j++)
{
System.out.print(name[i][j]+"\t");
}
System.out.println();
}
}
}
