//Write a program to get student details and store it into a file and print the name of the students who are eligible to vote.

import java.util.*;
import java.io.*;


class StudentAnalysis
{
public static void main(String[] args)
{
Scanner scr = new Scanner(System.in);
System.out.println("Enter the total number of students");
int n = scr.nextInt();

StudentDetails std = new StudentDetails();
std.getDetails(n);
try {
PrintStream output = new PrintStream(new File("StudentDetails.txt"));
//output.println("StudentID"+"\t"+"Name"+"\t\t"+"Age"+"\t\t"+"City"+"\t"+"Country");
//output.println(" ");
for(int i=0;i<n;i++)
{
for(int j=0;j<5;j++)
{
output.print(std.name[i][j]+"\t\t");
}
output.println();
}
output.close();
    }
catch(FileNotFoundException e)
{
System.out.println("File not found");
}

//
String str3[][]=new String[11][11];
try{
File inputFile = new File("StudentDetails.txt");
Scanner data = new Scanner(inputFile);

for(int i=0;i<n;i++)
{
for(int j=0;j<5;j++)
{
str3[i][j]=data.next();
}
}
}
catch(FileNotFoundException e)
{
System.out.println("error");
}

for(int i=0;i<n;i++)
{
for(int j=0;j<5;j++)
{
System.out.print(str3[i][j]);
System.out.print("\t");
}

System.out.println();
}

//logic to print students age above 21.

int countera=0;
for(int l=0;l<n;l++)
{
int k =2;
int p = Integer.parseInt(str3[l][2]);
if(p>=21)
{

countera ++;
//System.out.println("Student "+ str3[l][1]+" is eligible to vote");
}
}
System.out.println("The number of Students with age above 21 is "+ countera);


//logic to print student details with name starting with A

System.out.println("Details of the students whose name starts with a are");
System.out.println("StudentID: "+" student name: "+" student age "+" Student city is "+" Student country ");
for(int l=0;l<n;l++)
{
int k =1;
char c1 = (str3[l][1]).charAt(0);
if(c1=='a')
{
System.out.println(str3[l][0]+"\t\t"+str3[l][1]+"\t\t"+str3[l][2]+"\t\t"+str3[l][3]+"\t\t"+str3[l][4]);
}
}




//

}
}

class StudentDetails
{
public String name[][] = new String[11][11];
void getDetails(int n)
{
Scanner scr1 = new Scanner(System.in);

int limit = n;
System.out.println("Enter "+ limit + " Student details" );
for(int i =0; i<limit;i++)
{
System.out.println("Enter Student No. "+ (i+1)+ " Id"+" Name"+ " Age"+" City"+" Country");
for(int j=0;j<5;j++)
{
//
if(j==0)
{
System.out.println(" ");
System.out.println("Enter the student ID in the format S123 ");

}
//
else if(j==1)
{
System.out.println(" ");
System.out.println("Enter the student Name");
}

else if(j==2)
{
System.out.println(" ");
System.out.println("Enter the student Age, Age must be less than 100");
}


else if(j==3)
{
System.out.println(" ");
System.out.println("Enter the student City");
}

else if(j==4)
{
System.out.println(" ");
System.out.println("Enter the student country, Country must be India");
}




name [i][j] = scr1.nextLine(); 


}
}
display(limit);
}

void display(int limit)
{
System.out.println("StudentID"+"\t"+"Name"+"\t\t"+ "Age"+"\t\t"+" City"+"\t\t"+" Country");
for(int i=0;i<limit;i++)
{
for(int j =0;j<5;j++)
{
System.out.print(name[i][j]+"\t\t");
}
System.out.println();
}
}
}
