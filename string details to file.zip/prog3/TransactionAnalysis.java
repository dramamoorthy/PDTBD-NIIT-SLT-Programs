//Write a program to get student details and store it into a file and print the name of the students who are eligible to vote.

import java.util.*;
import java.io.*;


class TransactionAnalysis
{
public static void main(String[] args)
{
Scanner scr = new Scanner(System.in);
System.out.println("Enter the total number of transaction");
int n = scr.nextInt();

TransactionDetails std = new TransactionDetails();
std.getDetails(n);
try {
PrintStream output = new PrintStream(new File("TransactionDetails.txt"));
for(int i=0;i<n;i++)
{
for(int j=0;j<8;j++)
{
output.print(std.name[i][j]+"\t\t");
}
output.println();
}
output.close();
    }
catch(FileNotFoundException e)
{
System.out.println("File not found");
}

//
String str3[][]=new String[51][51];
try{
File inputFile = new File("TransactionDetails.txt");
Scanner data = new Scanner(inputFile);

for(int i=0;i<n;i++)
{
for(int j=0;j<8;j++)
{
str3[i][j]=data.next();
}
}
}
catch(FileNotFoundException e)
{
System.out.println("error");
}
/*
for(int i=0;i<n;i++)
{
for(int j=0;j<8;j++)
{
System.out.print(str3[i][j]);
System.out.print("\t");
}


System.out.println();
}
*/

//logic to print students age above 21.


for(int l=0;l<n;l++)
{
int k =6;
int p = Integer.parseInt(str3[l][7]);
if(p>25)
{
System.out.println("The  product "+ str3[l][1]+" has discount more than 25%");
}
}


int total=0;
for(int l=0;l<n;l++)
{
for(int j=0;j<n;j++)
{
if(str3[j][1]==str3[l][1])
{
int q=Integer.parseInt(str3[l][4]);
total=total+(q);
}
System.out.println("Total order for "+str3[j][l]+" is "+total);
}
}








//

}
}

class TransactionDetails
{
public String name[][] = new String[51][51];
void getDetails(int n)
{
Scanner scr1 = new Scanner(System.in);

int limit = n;
System.out.println("Enter "+ limit + " Transaction details" );
for(int i =0; i<limit;i++)
{
System.out.println("Enter details of Trans no. "+ (i+1)+ " Customer_Id"+" Product_ID"+ " Product_Price"+" Quantity"+"Total_price"+" Date"+" Product type"+" Discount percentage");
for(int j=0;j<8;j++)
{
//
if(j==0)
{
System.out.println(" ");
System.out.println("Enter the customer ID ");

}
//
else if(j==1)
{
System.out.println(" ");
System.out.println("Enter the product ID");
}

else if(j==2)
{
System.out.println(" ");
System.out.println("Enter the product price");
}


else if(j==3)
{
System.out.println(" ");
System.out.println("Enter the quantity");
}

else if(j==4)
{
System.out.println(" ");
System.out.println("Enter the total price");
}

else if(j==5)
{
System.out.println(" ");
System.out.println("Enter the date of purchase in format dd/mm/yyyy");
}

else if(j==6)
{
System.out.println(" ");
System.out.println("Enter the product type");
}

else if(j==7)
{
System.out.println(" ");
System.out.println("Enter the discount percentage");
}






name [i][j] = scr1.nextLine(); 


}
}
display(limit);
}

void display(int limit)
{
System.out.println("CustID"+"\t"+"ProdID"+"\t"+ "Price "+"Quantity"+"\t"+"TotalPrice"+"\t"+"Date"+"\t"+"Type"+"\t"+"Discount_Percentage");
for(int i=0;i<limit;i++)
{
for(int j =0;j<8;j++)
{
System.out.print(name[i][j]+"\t");
}
System.out.println();
}
}
}
